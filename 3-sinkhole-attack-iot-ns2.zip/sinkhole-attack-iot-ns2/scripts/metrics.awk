# Compute packet delivery ratio, average end-to-end delay, throughput and drops
# from an NS-2 *new wireless trace* (agent-layer CBR packets only).
# Usage: awk -f scripts/metrics.awk normal.tr
{
    ev = $1; t = $3
    layer = ""; ptype = ""; size = 0; id = ""
    for (i = 1; i <= NF; i++) {
        if ($i == "-Nl") layer = $(i + 1)
        else if ($i == "-It") ptype = $(i + 1)
        else if ($i == "-Il") size = $(i + 1)
        else if ($i == "-Ii") id = $(i + 1)
    }
    if (layer == "AGT" && ptype == "cbr") {
        if (ev == "s") { sent++; send_t[id] = t }
        else if (ev == "r") {
            recv++; bytes += size
            delay_sum += t - send_t[id]
            if (first_r == "") first_r = t
            last_r = t
        }
    }
    if (ev == "D" && ptype == "cbr") dropped++
}
END {
    pdr = (sent > 0) ? 100 * recv / sent : 0
    avg_delay = (recv > 0) ? 1000 * delay_sum / recv : 0
    span = last_r - first_r
    tput = (span > 0) ? bytes * 8 / span / 1000 : 0
    printf "Packets sent        : %d\n", sent
    printf "Packets received    : %d\n", recv
    printf "Packets dropped     : %d\n", dropped
    printf "Delivery ratio (%%)  : %.2f\n", pdr
    printf "Avg delay (ms)      : %.2f\n", avg_delay
    printf "Throughput (kbps)   : %.2f\n", tput
}
