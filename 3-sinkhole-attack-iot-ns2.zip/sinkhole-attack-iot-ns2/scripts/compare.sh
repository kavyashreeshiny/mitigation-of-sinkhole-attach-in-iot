#!/bin/sh
# Run all three scenarios and print a comparison table.
# Usage: sh scripts/compare.sh [seed]
SEED=${1:-1}
for m in normal attack defense; do
    ns sinkhole_sim.tcl $m $SEED > /dev/null
done
printf "%-10s %10s %12s %14s\n" Mode "PDR(%)" "Delay(ms)" "Thru(kbps)"
for m in normal attack defense; do
    awk -f scripts/metrics.awk $m.tr | awk -v m=$m -F: '
        /Delivery/ {p=$2} /Avg delay/ {d=$2} /Throughput/ {t=$2}
        END {printf "%-10s %10s %12s %14s\n", m, p, d, t}'
done
