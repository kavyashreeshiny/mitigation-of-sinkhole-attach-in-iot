# Sinkhole attack and Probe Route-based Defense (PRDSA) - NS-2.35 scenario
# Usage: ns sinkhole_sim.tcl <mode> [seed]
#   mode = normal | attack | defense
# Requires the patched AODV agent (see patch/README.md) for attack/defense modes.

set mode [lindex $argv 0]
if {$mode == ""} { set mode normal }
set seed [lindex $argv 1]
if {$seed == ""} { set seed 1 }
ns-random $seed

set val(chan)   Channel/WirelessChannel
set val(prop)   Propagation/TwoRayGround
set val(netif)  Phy/WirelessPhy
set val(mac)    Mac/802_11
set val(ifq)    Queue/DropTail/PriQueue
set val(ll)     LL
set val(ant)    Antenna/OmniAntenna
set val(ifqlen) 50
set val(rp)     AODV
set val(nn)     25
set val(x)      800
set val(y)      800
set val(stop)   100.0
set sink        0
set attacker    12

set ns [new Simulator]
set tracefd [open ${mode}.tr w]
$ns trace-all $tracefd
set namfd [open ${mode}.nam w]
$ns namtrace-all-wireless $namfd $val(x) $val(y)

set topo [new Topography]
$topo load_flatgrid $val(x) $val(y)
create-god $val(nn)

$ns node-config -adhocRouting $val(rp) -llType $val(ll) -macType $val(mac) \
    -ifqType $val(ifq) -ifqLen $val(ifqlen) -antType $val(ant) \
    -propType $val(prop) -phyType $val(netif) -channelType $val(chan) \
    -topoInstance $topo -agentTrace ON -routerTrace ON -macTrace OFF -movementTrace OFF

# random static placement (reproducible via seed)
set rng [new RNG]
$rng seed $seed
for {set i 0} {$i < $val(nn)} {incr i} {
    set node_($i) [$ns node]
    $node_($i) random-motion 0
    $node_($i) set X_ [expr {50 + [$rng uniform 0 700]}]
    $node_($i) set Y_ [expr {50 + [$rng uniform 0 700]}]
    $node_($i) set Z_ 0.0
    $ns initial_node_pos $node_($i) 30
}
# keep the sink in the middle so every flow has a multi-hop route
$node_($sink) set X_ 400.0
$node_($sink) set Y_ 400.0

# sink-bound CBR traffic from 6 sensor nodes
set sources {3 6 9 15 19 22}
set k 0
foreach s $sources {
    set udp($k) [new Agent/UDP]
    $ns attach-agent $node_($s) $udp($k)
    set null($k) [new Agent/Null]
    $ns attach-agent $node_($sink) $null($k)
    $ns connect $udp($k) $null($k)
    set cbr($k) [new Application/Traffic/CBR]
    $cbr($k) attach-agent $udp($k)
    $cbr($k) set packetSize_ 512
    $cbr($k) set interval_ 0.5
    $ns at [expr {10.0 + $k}] "$cbr($k) start"
    $ns at 95.0 "$cbr($k) stop"
    incr k
}

# attacker / defense switches (Tcl commands added by the AODV patch)
if {$mode == "attack" || $mode == "defense"} {
    $ns at 5.0 "\[\$node_($attacker) set ragent_\] sinkhole 1"
}
if {$mode == "defense"} {
    for {set i 0} {$i < $val(nn)} {incr i} {
        $ns at 0.5 "\[\$node_($i) set ragent_\] prdsa 1"
    }
}

proc finish {} {
    global ns tracefd namfd mode
    $ns flush-trace
    close $tracefd
    close $namfd
    puts "Simulation ($mode) finished -> ${mode}.tr"
    exit 0
}
for {set i 0} {$i < $val(nn)} {incr i} { $ns at $val(stop) "$node_($i) reset" }
$ns at $val(stop) "finish"
puts "Running mode=$mode seed=$seed"
$ns run
