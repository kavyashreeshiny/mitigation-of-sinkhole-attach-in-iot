# Mitigation of Sinkhole Attack in IoT Networks (NS-2.35)

Simulation study of a **sinkhole attack** on an AODV-routed wireless IoT/sensor network and a
**Probe Route-based Defense (PRDSA)**.

**Tools:** NS-2.35, C++, OTcl/Tcl, AWK

## How it works
- 25 static nodes in an 800 x 800 m area, 802.11 MAC, AODV routing.
- 6 source nodes send CBR traffic (512 B every 0.5 s) to a sink (node 0).
- **Attack:** node 12 replies to route requests with a forged "1 hop, very fresh" route, attracts
  traffic, then drops it.
- **Defense:** routes with suspicious replies are verified with a probe; failing next hops are
  blacklisted.
- `scripts/metrics.awk` parses the trace for delivery ratio, delay, throughput and drops.

## Files
| Path | Purpose |
|---|---|
| `sinkhole_sim.tcl` | Scenario (`normal`, `attack`, `defense` modes) |
| `patch/README.md` | C++ changes to merge into ns-2.35 AODV (attack + defense hooks) |
| `scripts/metrics.awk` | Trace analysis |
| `scripts/compare.sh` | Runs the 3 scenarios and prints a comparison table |
| `sample/sample_trace_for_testing.tr` | Tiny **synthetic** trace used only to test the AWK script |

## Run
```bash
# 1. Apply patch/README.md to ns-2.35, then rebuild NS-2
# 2. Run a scenario
ns sinkhole_sim.tcl normal 1      # baseline
ns sinkhole_sim.tcl attack 1      # with sinkhole
ns sinkhole_sim.tcl defense 1     # with PRDSA
# 3. Analyse
awk -f scripts/metrics.awk attack.tr
sh scripts/compare.sh 1
```
`normal` mode runs on stock NS-2.35; `attack` and `defense` need the patched AODV.

## Results
Add your own table after running `compare.sh` (try several seeds and average).

| Mode | PDR (%) | Delay (ms) | Throughput (kbps) |
|---|---|---|---|
| normal | | | |
| attack | | | |
| defense | | | |

## Status
The AWK analysis was tested on a synthetic trace. The Tcl scenario and C++ hooks have not been
run in NS-2 yet - run them, fix any build issues, and record real numbers before publishing.
