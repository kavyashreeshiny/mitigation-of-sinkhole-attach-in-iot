# AODV patch for NS-2.35 (sinkhole attacker + probe-based defense)

> **Status: reference code, not compiled.** NS-2 was not available where this repo was
> written, so the hooks below follow the ns-2.35 `aodv/aodv.{h,cc}` structure but must be
> merged and built on your machine (`make clean; make` in `ns-2.35/`). Line positions differ
> slightly between installs - search for the function names.

## 1. `aodv/aodv.h` - add members to `class AODV`
```cpp
    bool        sinkhole_;      // this node behaves as a sinkhole attacker
    bool        prdsa_;         // probe route-based defense enabled on this node
    nsaddr_t    blacklist_[64]; // next hops proven unreliable
    int         blacklist_n_;
    bool        isBlacklisted(nsaddr_t a);
    void        blacklist(nsaddr_t a);
```

## 2. `aodv/aodv.cc`
**Constructor** - initialise: `sinkhole_(false), prdsa_(false), blacklist_n_(0)`.

**Tcl switches** - inside `AODV::command()`, in the `argc == 3` block:
```cpp
    if (strcmp(argv[1], "sinkhole") == 0) { sinkhole_ = atoi(argv[2]); return TCL_OK; }
    if (strcmp(argv[1], "prdsa") == 0)    { prdsa_    = atoi(argv[2]); return TCL_OK; }
```

**Helpers**
```cpp
bool AODV::isBlacklisted(nsaddr_t a) {
    for (int i = 0; i < blacklist_n_; i++) if (blacklist_[i] == a) return true;
    return false;
}
void AODV::blacklist(nsaddr_t a) {
    if (!isBlacklisted(a) && blacklist_n_ < 64) blacklist_[blacklist_n_++] = a;
}
```

### Attack (sinkhole)
In `AODV::recvRequest()`, right after the reverse route to `rq->rq_src` has been created and
before the `if (rq->rq_dst == index)` test, advertise an irresistibly good route:
```cpp
    if (sinkhole_ && rq->rq_dst != index) {
        // forged RREP: 1 hop to destination, very large sequence number
        sendReply(rq->rq_src, 1, rq->rq_dst, rq->rq_dst_seqno + 200,
                  MY_ROUTE_TIMEOUT, rq->rq_timestamp);
        Packet::free(p);
        return;
    }
```
In `AODV::forward()` (top of function) attract-then-drop the data traffic:
```cpp
    if (sinkhole_ && ch->ptype() != PT_AODV && ih->saddr() != index) {
        drop(p, "SINKHOLE");
        return;
    }
```

### Defense (PRDSA - probe route-based)
Idea: do not trust a route reply blindly; **verify the route with a probe before using it**.

1. **Suspicion check** in `AODV::recvReply()` when `prdsa_` is true. Flag the reply if
   - its destination sequence number jumps far above the last one known for that destination
     (e.g. `rp->rp_dst_seqno > rt->rt_seqno + SEQ_JUMP_THRESHOLD`, threshold 50), or
   - the advertised hop count is 1 although the destination is not a radio neighbour.
2. **Probe**: for a flagged reply, hold the route in a "probation" state and send a probe
   packet toward the destination through the advertised next hop. The real destination answers
   with a probe reply.
3. **Decision**: if the probe reply arrives within the timeout, mark the route valid. If not,
   call `blacklist(next_hop)`, delete the route, and ignore future RREPs from that node
   (check `isBlacklisted(rp_src)` at the top of `recvReply()`).

Steps 1 and 3 are small additions to `recvReply()`. Step 2 needs a probe / probe-reply packet
type (define it like the existing AODV packet types in `aodv_packet.h` and add a timer in
`aodv.h`). That part is the bulk of the work - write and debug it yourself in NS-2; it is the
core of the project and the part you will be asked about.
